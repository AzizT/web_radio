A Pen created at CodePen.io. You can find this one at https://codepen.io/darkosxrc/pen/XyOEJP.

 Radio Player prototype for thewebradio.gr , with multiple stations.
Just a modern, responsive and minimal radio player.
Built with the awesome HowlerJS <3